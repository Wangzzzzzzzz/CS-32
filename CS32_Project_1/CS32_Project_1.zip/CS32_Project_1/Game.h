#ifndef GAME_H
#define GAME_H

class City;
class History;

class Game
{
	public:
		// Constructor/destructor
	Game(int rows, int cols, int nFlatulans);
	~Game();

	// Mutators
	void play();

private:
	City* m_city;
	History* m_history;
};

#endif
